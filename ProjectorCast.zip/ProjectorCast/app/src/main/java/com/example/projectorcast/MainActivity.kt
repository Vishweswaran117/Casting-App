package com.example.projectorcast

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.net.Inet4Address
import java.net.NetworkInterface
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private val renderers = mutableListOf<Renderer>()
    private lateinit var adapter: ArrayAdapter<Renderer>
    private lateinit var status: TextView
    private lateinit var fileLabel: TextView
    private var selected: Renderer? = null
    private var ext = "mp4"

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
        var name = "video.mp4"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) name = c.getString(i)
            }
        }
        FileServer.uri = uri
        FileServer.mime = contentResolver.getType(uri) ?: "video/mp4"
        FileServer.size = contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: 0L
        ext = name.substringAfterLast('.', "mp4").filter { it.isLetterOrDigit() }.ifEmpty { "mp4" }
        fileLabel.text = name
    }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)

        status = findViewById(R.id.status)
        fileLabel = findViewById(R.id.fileLabel)
        val list = findViewById<ListView>(R.id.deviceList)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_single_choice, renderers)
        list.adapter = adapter
        list.choiceMode = ListView.CHOICE_MODE_SINGLE
        list.setOnItemClickListener { _, _, pos, _ -> selected = renderers[pos] }

        findViewById<Button>(R.id.btnPick).setOnClickListener { picker.launch(arrayOf("video/*")) }

        findViewById<Button>(R.id.btnFind).setOnClickListener {
            renderers.clear(); selected = null; adapter.notifyDataSetChanged()
            status.text = "Searching..."
            Dlna.discover(this,
                onFound = { r ->
                    runOnUiThread {
                        if (renderers.none { it.avUrl == r.avUrl }) {
                            renderers.add(r); adapter.notifyDataSetChanged()
                        }
                    }
                },
                onDone = {
                    runOnUiThread {
                        status.text = if (renderers.isEmpty())
                            "No projector found. Is it on the same Wi-Fi?" else "Tap your projector in the list"
                    }
                })
        }

        findViewById<Button>(R.id.btnPlay).setOnClickListener { castNow() }
        findViewById<Button>(R.id.btnPause).setOnClickListener { ctl { Dlna.pause(it) } }
        findViewById<Button>(R.id.btnResume).setOnClickListener { ctl { Dlna.play(it) } }
        findViewById<Button>(R.id.btnBack).setOnClickListener {
            ctl { Dlna.seek(it, maxOf(0L, Dlna.position(it) - 10)) }
        }
        findViewById<Button>(R.id.btnFwd).setOnClickListener {
            ctl { Dlna.seek(it, Dlna.position(it) + 10) }
        }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            ctl { Dlna.stop(it) }
            stopService(Intent(this, CastService::class.java))
        }
        findViewById<SeekBar>(R.id.volume).setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                val v = sb?.progress ?: return
                ctl { Dlna.setVolume(it, v) }
            }
        })
    }

    private fun castNow() {
        val r = selected
        if (r == null) { toast("Find and tap your projector first"); return }
        if (FileServer.uri == null) { toast("Choose a movie first"); return }

        ContextCompat.startForegroundService(this, Intent(this, CastService::class.java))
        ui("Sending to ${r.name}...")
        thread {
            try {
                val port = FileServer.start(applicationContext)
                val ip = localIp() ?: throw IllegalStateException("No Wi-Fi address. Connect to Wi-Fi.")
                val url = "http://$ip:$port/video.$ext"
                runCatching { Dlna.stop(r) }
                Dlna.setUri(r, url, fileLabel.text.toString(), FileServer.mime)
                Dlna.play(r)
                ui("Playing on ${r.name}")
            } catch (e: Exception) {
                ui("Error: ${e.message}")
            }
        }
    }

    private fun ctl(action: (Renderer) -> Unit) {
        val r = selected ?: return
        thread {
            try { action(r) } catch (e: Exception) { ui("Error: ${e.message}") }
        }
    }

    private fun localIp(): String? =
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .sortedBy { if (it.name.startsWith("wlan") || it.name.startsWith("ap")) 0 else 1 }
            .flatMap { it.inetAddresses.toList() }
            .firstOrNull { it is Inet4Address && it.isSiteLocalAddress }
            ?.hostAddress

    private fun ui(msg: String) = runOnUiThread { status.text = msg }
    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
