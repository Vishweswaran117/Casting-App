package com.example.projectorcast

import android.content.Context
import android.net.Uri
import java.io.BufferedOutputStream
import java.io.FileInputStream
import java.io.IOException
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread

/** Tiny HTTP server that streams the chosen video to the projector, with Range (seek) support. */
object FileServer {
    @Volatile var uri: Uri? = null
    @Volatile var mime: String = "video/mp4"
    @Volatile var size: Long = 0

    private var server: ServerSocket? = null
    private lateinit var app: Context

    @Synchronized
    fun start(ctx: Context): Int {
        server?.let { if (!it.isClosed) return it.localPort }
        app = ctx.applicationContext
        val ss = try { ServerSocket(8080) } catch (e: IOException) { ServerSocket(0) }
        server = ss
        thread(isDaemon = true) {
            while (!ss.isClosed) {
                try {
                    val s = ss.accept()
                    thread(isDaemon = true) { handle(s) }
                } catch (_: IOException) {
                }
            }
        }
        return ss.localPort
    }

    @Synchronized
    fun stop() {
        try { server?.close() } catch (_: Exception) {}
        server = null
    }

    private fun handle(s: Socket) {
        try {
            s.use {
                val reader = s.getInputStream().bufferedReader(Charsets.ISO_8859_1)
                val first = reader.readLine() ?: return
                val method = first.split(" ")[0]
                var range: String? = null
                while (true) {
                    val line = reader.readLine() ?: break
                    if (line.isEmpty()) break
                    if (line.startsWith("Range:", ignoreCase = true)) range = line.substringAfter(":").trim()
                }
                val out = BufferedOutputStream(s.getOutputStream())
                val u = uri
                val total = size
                if (u == null || total <= 0) {
                    out.write("HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray())
                    out.flush(); return
                }

                var start = 0L
                var end = total - 1
                var partial = false
                range?.let { r ->
                    Regex("bytes=(\\d*)-(\\d*)").find(r)?.let { m ->
                        val a = m.groupValues[1]
                        val b = m.groupValues[2]
                        if (a.isNotEmpty()) {
                            start = a.toLong()
                            if (b.isNotEmpty()) end = minOf(b.toLong(), total - 1)
                        } else if (b.isNotEmpty()) {
                            start = maxOf(0L, total - b.toLong())
                        }
                        partial = true
                    }
                }
                if (start >= total || start > end) {
                    out.write("HTTP/1.1 416 Range Not Satisfiable\r\nContent-Range: bytes */$total\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray())
                    out.flush(); return
                }

                val len = end - start + 1
                val h = StringBuilder()
                h.append(if (partial) "HTTP/1.1 206 Partial Content\r\n" else "HTTP/1.1 200 OK\r\n")
                h.append("Content-Type: $mime\r\n")
                h.append("Content-Length: $len\r\n")
                h.append("Accept-Ranges: bytes\r\n")
                if (partial) h.append("Content-Range: bytes $start-$end/$total\r\n")
                h.append("transferMode.dlna.org: Streaming\r\n")
                h.append("contentFeatures.dlna.org: DLNA.ORG_OP=01;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=01700000000000000000000000000000\r\n")
                h.append("Connection: close\r\n\r\n")
                out.write(h.toString().toByteArray())
                if (method == "HEAD") { out.flush(); return }

                app.contentResolver.openFileDescriptor(u, "r")?.use { pfd ->
                    val fis = FileInputStream(pfd.fileDescriptor)
                    fis.channel.position(start)
                    val buf = ByteArray(64 * 1024)
                    var left = len
                    while (left > 0) {
                        val n = fis.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                        if (n < 0) break
                        out.write(buf, 0, n)
                        left -= n
                    }
                }
                out.flush()
            }
        } catch (_: IOException) {
            // Projector closed the connection (normal when seeking).
        }
    }
}
