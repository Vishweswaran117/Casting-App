package com.example.projectorcast

import android.content.Context
import android.net.wifi.WifiManager
import org.w3c.dom.Element
import org.xml.sax.InputSource
import java.io.IOException
import java.io.StringReader
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.URL
import javax.xml.parsers.DocumentBuilderFactory
import kotlin.concurrent.thread

data class Renderer(
    val name: String,
    val avType: String,
    val avUrl: String,
    val rcType: String?,
    val rcUrl: String?
) {
    override fun toString() = name
}

object Dlna {

    // ---------- Discovery (SSDP) ----------
    fun discover(ctx: Context, onFound: (Renderer) -> Unit, onDone: () -> Unit) = thread {
        val wifi = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val lock = wifi.createMulticastLock("projector-cast").apply {
            setReferenceCounted(false); acquire()
        }
        val seen = HashSet<String>()
        try {
            DatagramSocket().use { sock ->
                sock.soTimeout = 1000
                val msg = ("M-SEARCH * HTTP/1.1\r\n" +
                        "HOST: 239.255.255.250:1900\r\n" +
                        "MAN: \"ssdp:discover\"\r\n" +
                        "MX: 2\r\n" +
                        "ST: urn:schemas-upnp-org:device:MediaRenderer:1\r\n\r\n").toByteArray()
                val group = InetAddress.getByName("239.255.255.250")
                repeat(2) { sock.send(DatagramPacket(msg, msg.size, group, 1900)) }
                val end = System.currentTimeMillis() + 5000
                val buf = ByteArray(2048)
                while (System.currentTimeMillis() < end) {
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        sock.receive(p)
                        val text = String(p.data, 0, p.length)
                        val loc = Regex("(?im)^location:\\s*(.+)$").find(text)
                            ?.groupValues?.get(1)?.trim() ?: continue
                        if (seen.add(loc)) fetch(loc)?.let(onFound)
                    } catch (_: SocketTimeoutException) {
                    }
                }
            }
        } catch (_: Exception) {
        } finally {
            lock.release()
            onDone()
        }
    }

    private fun fetch(loc: String): Renderer? = try {
        val c = URL(loc).openConnection() as HttpURLConnection
        c.connectTimeout = 3000
        c.readTimeout = 3000
        val xml = c.inputStream.bufferedReader().readText()
        val doc = DocumentBuilderFactory.newInstance().newDocumentBuilder()
            .parse(InputSource(StringReader(xml)))
        val name = doc.getElementsByTagName("friendlyName").item(0)?.textContent?.trim() ?: "Unknown device"
        var av: Pair<String, String>? = null
        var rc: Pair<String, String>? = null
        val services = doc.getElementsByTagName("service")
        for (i in 0 until services.length) {
            val e = services.item(i) as Element
            val type = e.getElementsByTagName("serviceType").item(0)?.textContent?.trim() ?: continue
            val ctl = e.getElementsByTagName("controlURL").item(0)?.textContent?.trim() ?: continue
            val full = URL(URL(loc), ctl).toString()
            if (type.contains("AVTransport")) av = type to full
            if (type.contains("RenderingControl")) rc = type to full
        }
        av?.let { Renderer(name, it.first, it.second, rc?.first, rc?.second) }
    } catch (e: Exception) {
        null
    }

    // ---------- Commands (SOAP) ----------
    fun setUri(r: Renderer, url: String, title: String, mime: String) {
        val didl = "<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" " +
                "xmlns:dc=\"http://purl.org/dc/elements/1.1/\" " +
                "xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\">" +
                "<item id=\"1\" parentID=\"0\" restricted=\"1\">" +
                "<dc:title>${esc(title)}</dc:title>" +
                "<upnp:class>object.item.videoItem</upnp:class>" +
                "<res protocolInfo=\"http-get:*:$mime:DLNA.ORG_OP=01;DLNA.ORG_CI=0;" +
                "DLNA.ORG_FLAGS=01700000000000000000000000000000\">$url</res>" +
                "</item></DIDL-Lite>"
        soap(r.avUrl, r.avType, "SetAVTransportURI",
            "<InstanceID>0</InstanceID><CurrentURI>$url</CurrentURI>" +
                    "<CurrentURIMetaData>${esc(didl)}</CurrentURIMetaData>")
    }

    fun play(r: Renderer) =
        soap(r.avUrl, r.avType, "Play", "<InstanceID>0</InstanceID><Speed>1</Speed>")

    fun pause(r: Renderer) =
        soap(r.avUrl, r.avType, "Pause", "<InstanceID>0</InstanceID>")

    fun stop(r: Renderer) =
        soap(r.avUrl, r.avType, "Stop", "<InstanceID>0</InstanceID>")

    fun position(r: Renderer): Long {
        val resp = soap(r.avUrl, r.avType, "GetPositionInfo", "<InstanceID>0</InstanceID>")
        val m = Regex("<RelTime>(\\d+):(\\d+):(\\d+)").find(resp) ?: return 0
        val (h, mi, s) = m.destructured
        return h.toLong() * 3600 + mi.toLong() * 60 + s.toLong()
    }

    fun seek(r: Renderer, seconds: Long) {
        val t = "%d:%02d:%02d".format(seconds / 3600, (seconds % 3600) / 60, seconds % 60)
        soap(r.avUrl, r.avType, "Seek",
            "<InstanceID>0</InstanceID><Unit>REL_TIME</Unit><Target>$t</Target>")
    }

    fun setVolume(r: Renderer, volume: Int) {
        val url = r.rcUrl ?: return
        val type = r.rcType ?: return
        soap(url, type, "SetVolume",
            "<InstanceID>0</InstanceID><Channel>Master</Channel><DesiredVolume>$volume</DesiredVolume>")
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;")
        .replace(">", "&gt;").replace("\"", "&quot;")

    private fun soap(url: String, type: String, action: String, args: String): String {
        val body = """<?xml version="1.0" encoding="utf-8"?>
<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:$action xmlns:u="$type">$args</u:$action></s:Body></s:Envelope>"""
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 4000
        c.readTimeout = 6000
        c.setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"")
        c.setRequestProperty("SOAPACTION", "\"$type#$action\"")
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        val text = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        if (code >= 400) throw IOException("Projector refused $action (HTTP $code)")
        return text
    }
}
